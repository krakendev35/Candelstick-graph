# https://youtu.be/elYwHVVoiOE
import pandas_datareader as web
import mplfinance as mpl
import datetime as dt

start = dt.datetime(2020,1,1)
end = dt.datetime.now()

data = web.DataReader('XRP-USD', 'yahoo', start,end)

mpl.plot(data,type='candle',volume =True,style='yahoo')
